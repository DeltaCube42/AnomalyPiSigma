$modelname "props_custom/sitting.mdl"
$body "Body" "Sitting_reference.smd"
$staticprop
$surfaceprop "flesh"
$cdmaterials "models/props_custom/sitting/"
$sequence "idle" "Sitting_reference.smd" fps 1
$scale 1