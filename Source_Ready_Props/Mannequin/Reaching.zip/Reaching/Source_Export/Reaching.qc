$modelname "props_custom/reaching.mdl"
$body "Body" "Reaching_reference.smd"
$staticprop
$surfaceprop "flesh"
$cdmaterials "models/props_custom/reaching/"
$sequence "idle" "Reaching_reference.smd" fps 1
$scale 1
