$modelname "props_custom/mf_doom_wearable.mdl"
$body "Body" "MF_DOOM_Wearable_reference.smd"
$staticprop
$surfaceprop "metal"
$cdmaterials "models/props_custom/mf_doom_wearable/"
$sequence "idle" "MF_DOOM_Wearable_reference.smd" fps 1
$scale 1