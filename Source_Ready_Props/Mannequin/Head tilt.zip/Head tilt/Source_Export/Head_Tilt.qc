$modelname "props_custom/head_tilt.mdl"
$body "Body" "Head_Tilt_reference.smd"
$staticprop
$surfaceprop "flesh"
$cdmaterials "models/props_custom/head_tilt/"
$sequence "idle" "Head_Tilt_reference.smd" fps 1
$scale 1