
$modelname "props_custom/scp184.mdl"
$body "Body" "SCP184_reference.smd"
$staticprop
$surfaceprop "metal"
$cdmaterials "models/props_custom/scp184/"
$sequence "idle" "SCP184_reference.smd" fps 1
$scale 1
