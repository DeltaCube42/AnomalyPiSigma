 $modelname "props_custom/standing.mdl"
$body "Body" "Standing_reference.smd"
$staticprop
$surfaceprop "flesh"
$cdmaterials "models/props_custom/standing/"
$sequence "idle" "Standing_reference.smd" fps 1
