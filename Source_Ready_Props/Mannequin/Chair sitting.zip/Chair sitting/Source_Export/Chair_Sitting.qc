$modelname "props_custom/chair_sitting.mdl"
$body "Body" "Chair_Sitting_reference.smd"
$staticprop
$surfaceprop "flesh"
$cdmaterials "models/props_custom/chair_sitting/"
$sequence "idle" "Chair_Sitting_reference.smd" fps 1
$scale 1