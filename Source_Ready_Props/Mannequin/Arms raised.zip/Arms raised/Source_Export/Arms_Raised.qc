$modelname "props_custom/arms_raised.mdl"
$body "Body" "Arms_Raised_reference.smd"
$staticprop
$surfaceprop "flesh"
$cdmaterials "models/props_custom/arms_raised/"
$sequence "idle" "Arms_Raised_reference.smd" fps 1
