$modelname "props_custom/mf_doom_mask.mdl"
$body "Body" "MF_DOOM_Mask_reference.smd"
$staticprop
$surfaceprop "metal"
$cdmaterials "models/props_custom/mf_doom_mask/"
$sequence "idle" "MF_DOOM_Mask_reference.smd" fps 1
$scale 1